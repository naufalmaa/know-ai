'use client'
import { useEffect, useState } from 'react'
import { usePathname } from 'next/navigation'
import Navbar from '@/components/layout/Navbar'
import Sidebar from '@/components/drive/Sidebar'
import { api } from '@/lib/api'

interface ConditionalLayoutProps {
  children: React.ReactNode
}

export default function ConditionalLayout({ children }: ConditionalLayoutProps) {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null)
  const [user, setUser] = useState<any>(null)
  const pathname = usePathname()
  
  // Check if current page should show sidebar
  const isLandingPage = pathname === '/'
  const shouldShowSidebar = isAuthenticated && !isLandingPage

  useEffect(() => {
    checkAuth()
  }, [])

  const checkAuth = async () => {
    try {
      const response = await fetch(api('/api/auth/me'), {
        credentials: 'include'
      })
      if (response.ok) {
        const userData = await response.json()
        setUser(userData)
        setIsAuthenticated(true)
      } else {
        setUser(null)
        setIsAuthenticated(false)
      }
    } catch (error) {
      setUser(null)
      setIsAuthenticated(false)
    }
  }

  return (
    <>
      {/* Global Navbar */}
      <Navbar user={user} isAuthenticated={isAuthenticated} onAuthChange={checkAuth} />
      
      {/* Conditional Layout */}
      {shouldShowSidebar ? (
        <div className="flex">
          {/* Sidebar for authenticated pages */}
          <Sidebar />
          
          {/* Main Content with sidebar */}
          <main className="flex-1 bg-white min-h-screen">
            {children}
          </main>
        </div>
      ) : (
        /* Main Content without sidebar (landing page) */
        <main className="bg-white min-h-screen">
          {children}
        </main>
      )}
    </>
  )
}