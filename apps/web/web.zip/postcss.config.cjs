/** Next 15 + Tailwind v4 (Windows-friendly) */
module.exports = {
  plugins: {
    "@tailwindcss/postcss": {},
    autoprefixer: {},
  },
};
